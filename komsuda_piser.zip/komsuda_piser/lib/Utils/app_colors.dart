import 'package:flutter/material.dart';

class Appcolors {
  static const Color primary = Color(0xfff2a258);
  static const Color secondary = Color(0xFFF2EF58);
  static const Color third = Color(0xffF2585B);
  static const Color black = Color(0xfff2a258);
  static const Color text = Color(0xff2A2A2A);
  static const Color background = Color(0xFFEAEAEA);

}
