import 'package:flutter/material.dart';

const kPadding = 20.0;
const maxWidth = 1232.0;