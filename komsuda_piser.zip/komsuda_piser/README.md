# komsuda_piser_local

A new online food delivery application called Komsuda Piser.
Front-end: Flutter
Back-end: Firebase
Contributors: Utku Gürsoy,
              EgeBerk Yurtkoruyan,
              Okan Sarp Kaya.
<img width="1680" alt="Screen Shot 2021-12-19 at 12 33 46" src="https://user-images.githubusercontent.com/79059842/146670224-4e389b48-6ad3-47a5-ac54-0f96b21ffbd0.png">

