package com.example.komsuda_piser_local

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
